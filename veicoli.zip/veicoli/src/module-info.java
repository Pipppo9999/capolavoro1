/**
 * 
 */
/**
 * @author ALUNNI
 *
 */
module veicoli {
}