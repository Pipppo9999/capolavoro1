package veicoli;

public class veicoli_main {

    public static void main(String[] args) {
        int dim=30;
    	String targa="";
    	
        veicoli_costr[] VC=new veicoli_costr[dim];
        autoveicoli1[] A1=new autoveicoli1[dim];
        autocarri1[] A2=new autocarri1[dim];
        motocicli1[] M1=new motocicli1[dim];
        int minPorte = 0;
        int maxCilindrata = 0;
        
        for(int k=0; k<VC.length; k++) {
            VC[k]=new veicoli_costr();
            A1[k] = new autoveicoli1(); 
            A2[k] = new autocarri1(); 
            M1[k] = new motocicli1(); 
        }
        
        System.out.println("inserisci i dati dei veicoli: ");
        inserisci_dati(VC, A1, A2, M1);
        
        System.out.println("stampa i dati dei veicoli: ");
        stampa_dati(A1, A2, M1);
        
        minPorte = trovaMinimoPorte(A1);
        maxCilindrata = trovaMassimoCilindrata(M1);
        
        System.out.println("Il minimo numero di porte tra gli autoveicoli è: " + minPorte);
        System.out.println("La massima cilindrata tra i motocicli è: " + maxCilindrata);
        
        ordinaAutocarriPerCapacita(A2, dim);
        System.out.println("Elenco degli autocarri in ordine crescente di capacità:");
        stampa_dati_autocarri(A2);
        
        ricercaVeicoloPerTarga(targa, A1, A2, M1);
    }
    
    public static void inserisci_dati(veicoli_costr VC[], autoveicoli1[] A1, autocarri1[] A2, motocicli1[] M1) {
        
        input inp = new input();
        
        for (int k = 0; k < VC.length; k++) {    
            int r = inp.leggi_Intero("Che tipo di veicolo è? 1 per autoveicoli, 2 per autocarri, 3 per motocicli");
            switch (r) {
                case 1:
                    A1[k].setNumporte(inp.leggi_Intero("Inserisci il numero di porte: "));
                    A1[k].marca = inp.leggi_Stringa("Inserisci la marca: ");
                    A1[k].targa = inp.leggi_Intero("Inserisci il numero di targa: ");
                    A1[k].modello = inp.leggi_Stringa("Inserisci il modello: ");
                    A1[k].numposti = inp.leggi_Intero("Inserisci il numero di posti: ");
                    break;
                case 2:
                    A2[k].setCapmax(inp.leggi_Intero("Inserisci la capacità massima: "));
                    A2[k].marca = inp.leggi_Stringa("Inserisci la marca: ");
                    A2[k].targa = inp.leggi_Intero("Inserisci il numero di targa: ");
                    A2[k].modello = inp.leggi_Stringa("Inserisci il modello: ");
                    A2[k].numposti = inp.leggi_Intero("Inserisci il numero di posti: ");
                    break;
                case 3:
                    M1[k].setCilindrata(inp.leggi_Intero("Inserisci la cilindrata: "));
                    M1[k].marca = inp.leggi_Stringa("Inserisci la marca: ");
                    M1[k].targa = inp.leggi_Intero("Inserisci il numero di targa: ");
                    M1[k].modello = inp.leggi_Stringa("Inserisci il modello: ");
                    M1[k].numposti = inp.leggi_Intero("Inserisci il numero di posti: ");
                    break;
                default:
                    System.out.println("Tipo di veicolo non valido!");
                    break;
            }
        }
    }
    
    public static void stampa_dati(autoveicoli1[] A1, autocarri1[] A2, motocicli1[] M1) {
        
        for (int k = 0; k < A1.length; k++) {
            if (A1[k] != null) {
                System.out.println("Marca: " + A1[k].marca); 
                System.out.println("Numero di targa: " + A1[k].targa); 
                System.out.println("Modello: " + A1[k].modello); 
                System.out.println("Numero di posti: " + A1[k].numposti); 
                System.out.println("Numero di porte: " + A1[k].getNumporte());
            } else if (A2[k] != null) {
                System.out.println("Marca: " + A2[k].marca); 
                System.out.println("Numero di targa: " + A2[k].targa); 
                System.out.println("Modello: " + A2[k].modello); 
                System.out.println("Numero di posti: " + A2[k].numposti); 
                System.out.println("Capacità massima: " + A2[k].getCapmax());
            } else if (M1[k] != null) {
                System.out.println("Marca: " + M1[k].marca); 
                System.out.println("Numero di targa: " + M1[k].targa); 
                System.out.println("Modello: " + M1[k].modello); 
                System.out.println("Numero di posti: " + M1[k].numposti); 
                System.out.println("Cilindrata: " + M1[k].getCilindrata());
            }
        }
    }
	
	
	
    public static int trovaMinimoPorte(autoveicoli1[] A1) {
        int minPorte = Integer.MAX_VALUE;
        for (int k = 0; k < A1.length; k++) {
            if (A1[k] != null) {
                int numPorte = A1[k].getNumporte();
                if (numPorte < minPorte) {
                    minPorte = numPorte;
                }
            }
        }
        return minPorte;
    }
	
    public static int trovaMassimoCilindrata(motocicli1[] M1) {
        int maxCilindrata = Integer.MIN_VALUE;
        for (int k = 0; k < M1.length; k++) {
            if (M1[k] != null) {
                int cilindrata = M1[k].getCilindrata();
                if (cilindrata > maxCilindrata) {
                    maxCilindrata = cilindrata;
                }
            }
        }
        return maxCilindrata;
    }
    
    public static void ordinaAutocarriPerCapacita(autocarri1[] A2, int dim) {
        boolean check=false;
        
        do {
        	check=false;
        	
        	for(int k=0; k<dim-1-k; k++) {
        		if(A2[k].getCapmax()>A2[k+1].getCapmax()) {
        			swap(A2, k);
        			check=true;
        		}
        	}
        }while(check);
    }
    
    public static void swap(autocarri1[] A2, int k) {
    	
    	autocarri1 temp= A2[k];
    	A2[k]=A2[k+1];
    	A2[k+1]=temp;
    }
    
    public static void stampa_dati_autocarri(autocarri1[] A2) {
        for (int k = 0; k < A2.length; k++) {
            if (A2[k] != null) {
                autocarri1 auto = A2[k];
                System.out.println("Marca: " + auto.marca); 
                System.out.println("Numero di targa: " + auto.targa); 
                System.out.println("Modello: " + auto.modello); 
                System.out.println("Numero di posti: " + auto.numposti); 
                System.out.println("Capacità massima: " + auto.getCapmax());
            }
        }
    }
    
    public static void ricercaVeicoloPerTarga(String targa, autoveicoli1[] A1, autocarri1[] A2, motocicli1[] M1) {
        
    	boolean trovato = false;
        
		        for (int i = 0; i < A1.length; i++) {
		            autoveicoli1 auto = A1[i];
		            if (targa.equals(auto.targa)) {
		                System.out.println("Veicolo trovato:");
		                System.out.println("Marca: " + auto.marca); 
		                System.out.println("Modello: " + auto.modello); 
		                System.out.println("Numero di posti: " + auto.numposti); 
		                System.out.println("Numero di porte: " + auto.getNumporte());
		                trovato = true;
		                break;
		            }
		        }
		        
		        for (int i = 0; i < A2.length; i++) {
		            autocarri1 auto = A2[i];
		            if (targa.equals(auto.targa)) {
		                System.out.println("Veicolo trovato:");
		                System.out.println("Marca: " + auto.marca); 
		                System.out.println("Modello: " + auto.modello); 
		                System.out.println("Numero di posti: " + auto.numposti); 
		                System.out.println("Capacità massima: " + auto.getCapmax());
		                trovato = true;
		                break;
		            }
		        }
		
		        for (int i = 0; i < M1.length; i++) {
		            motocicli1 moto = M1[i];
		            if (targa.equals(moto.targa)) {
		                System.out.println("Veicolo trovato:");
		                System.out.println("Marca: " + moto.marca); 
		                System.out.println("Modello: " + moto.modello); 
		                System.out.println("Numero di posti: " + moto.numposti); 
		                System.out.println("Cilindrata: " + moto.getCilindrata());
		                trovato = true;
		                break;
		            }
		        }
        
        if (!trovato) {
            System.out.println("Veicolo non trovato con la targa specificata.");
        }
    }
}

