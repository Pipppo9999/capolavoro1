package veicoli;
import java.io.*;

public class input {
	
	InputStreamReader input = new InputStreamReader(System.in);
    BufferedReader tastiera = new BufferedReader(input);
    
    public String leggi_Stringa(String s) {
    	
    	System.out.print(s);
    	
    	try {
    		return this.tastiera.readLine();
    	} catch(IOException e){
    		System.out.println("errore");
    		return "";
    	}
    }
    
    public int leggi_Intero(String s) {
    	
    	System.out.print(s);
    	
    	try {
    		int i=Integer.valueOf(this.tastiera.readLine()).intValue();
    		return i;
    	} catch(IOException e){
    		System.out.println("errore");
    		return 0;
    	}
    }
	
    public float leggi_Float(String s) {
    	
    	System.out.print(s);
    	
    	try {
    		float f=Float.valueOf(this.tastiera.readLine()).intValue();
    		return f;
    	} catch(IOException e){
    		System.out.println("errore");
    		return 0.0f;
    	}
    }
    
}

