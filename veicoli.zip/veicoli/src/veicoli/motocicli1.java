package veicoli;

public class motocicli1 extends veicoli_costr {

	public int cilindrata=0;
	
	public motocicli1() {
		
		super();
		this.cilindrata=1;
	
	}
	
	public motocicli1(String marca, String modello, int targa, int numposti, int cilindrata) {
		
		super(marca, modello, targa, numposti);
		this.cilindrata=cilindrata;
	
	}

	public int getCilindrata() {
		return cilindrata;
	}

	public void setCilindrata(int cilindrata) {
		this.cilindrata = cilindrata;
	}

	public void stampa_dati() {
		
		super.stampa_dati();
		System.out.println("cilindrata: "+this.cilindrata);
    }

}
