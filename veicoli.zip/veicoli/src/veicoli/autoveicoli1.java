package veicoli;

public class autoveicoli1 extends veicoli_costr {
	
		private int numporte=0;

		public autoveicoli1() {
			
			super();
			this.numporte=1;
		
		}
		
		public autoveicoli1(String marca, String modello, int targa, int numposti, int numporte) {
			
			super(marca, modello, targa, numposti);
			this.numporte=numporte;
		
		}

		public int getNumporte() {
			return numporte;
		}

		public void setNumporte(int numporte) {
			this.numporte = numporte;
		}
		
		public void stampa_dati() {
			
			super.stampa_dati();
			System.out.println("numero porte: "+this.numporte);
	    }
}
