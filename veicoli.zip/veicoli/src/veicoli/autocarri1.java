package veicoli;

public class autocarri1 extends veicoli_costr {

	public float capmax=0;
	
	public autocarri1() {
		
		super();
		this.capmax=1;
	
	}
	
	public autocarri1(String marca, String modello, int targa, int numposti, int capmax) {
		
		super(marca, modello, targa, numposti);
		this.capmax=capmax;
	}

	public float getCapmax() {
		return capmax;
	}

	public void setCapmax(float capmax) {
		this.capmax = capmax;
	}

	public void stampa_dati() {
		
		super.stampa_dati();
		System.out.println("capienza massima: "+this.capmax);
    }
}
