package veicoli;

public class veicoli_costr {
	
	protected String modello="";
	protected String marca="";
	protected int targa=0;
	protected int numposti=0;
	
	public veicoli_costr() {
		
		this.modello="";
		this.marca="";
		this.targa=1;
		this.numposti=1;
	
	}
	
	public veicoli_costr(String marca, String modello, int targa, int numposti) {
		
		this.modello=modello;
		this.marca=marca;
		this.targa=targa;
		this.numposti = numposti;
	
	}

	public String getModello() {
		return modello;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getTarga() {
		return targa;
	}

	public void setTarga(int targa) {
		this.targa = targa;
	}

	public int getNumposti() {
		return numposti;
	}

	public void setNumposti(int numposti) {
		this.numposti = numposti;
	}
	
	public void stampa_dati() {
		
			System.out.println("marca: "+this.marca);
			System.out.println("modello: "+this.modello);
			System.out.println("targa: "+this.targa);
			System.out.println("capacità: "+this.numposti);
	}
	
}
